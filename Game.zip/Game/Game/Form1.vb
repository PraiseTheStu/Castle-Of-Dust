﻿Public Class Form1
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Dim Userinput1 As String
        Dim Input1 As Boolean
        Dim userinput2 As String
        Dim input2 As Boolean
        Dim userinput3 As String
        Dim userinput4 As String
        Dim input3 As Boolean

        Dim dodge1 As String
        Dim dodge2 As String

        Input1 = False
        input2 = False
        input3 = False
        lstDisplay.Items.Add("You arrive at a large gate. It looks old, large and heavy. You could try shoving it open, or try knocking")
        Do Until Userinput1 = "Shove" Or "shove"
            Userinput1 = InputBox("")
        Loop
        If Userinput1 = ("PraiseTheStu0141") Then
                lstDisplay.Items.Add("Why Thank you!")
                lstDisplay.Items.Add("01010111 01100101 01101100 01100011 01101111 01101101 01100101 00100000 01110100 01101111 00100000 01110100 01101000 01100101 00100000 01100011 01101111 01100001 01101100 01101001 01110100 01101001 01101111 01101110 00100000 01001010 01000011 00100001 ")
            End If
            If Userinput1 = "Knock" Or "knock" Then
                lstDisplay.Items.Add("You knock on the door,  the bangs echoing  through the castle within, though nobody answers")
            ElseIf Userinput1 = "Shove" Or "shove" Then
                Input1 = True
                lstDisplay.Items.Add("The door pushes open, revealing the dusty ruins of the ancient castle. Skeletons of the ancient residents line the streets")
            End If


            If Input1 = True Then
            lstDisplay.Items.Add("")
            lstDisplay.Items.Add("You pass the guard's armory.")
            lstDisplay.Items.Add("Do you go inside and investigate?")
            Do Until userinput2 = "No" Or "Yes" Or "no" Or "yes"
                userinput2 = InputBox("Yes or No?")
            Loop
            If userinput2 = "No" Then
                lstDisplay.Items.Add("You choose not to investigate the armory")
            ElseIf userinput2 = "Yes" Then
                input2 = True
                lstDisplay.Items.Add("You choose to investigate the armory. Inside you find naught but dust and skeletons")
                lstDisplay.Items.Add("However, as you are leaving, you find a iron longsword in the grip of an old dusty skeleton")
                lstDisplay.Items.Add("You pry the sword from the boney hands and take it with you")
            End If
            lstDisplay.Items.Add("")
        End If
        lstDisplay.Items.Add("You arrive at the castle's enterance, however unlike the area before the main castle")
        lstDisplay.Items.Add("the castle itself was far from deserted. A large green orc stands guard at the gate")
        lstDisplay.Items.Add("He growls at you and charges forward to attack")
        If input2 = False Then
            lstDisplay.Items.Add("The orc charges straight at you, but you have nothing to defend yourself with!")
            lstDisplay.Items.Add("The orc slashes his axe across your chest and you stumble backwards faintly!")
            lstDisplay.Items.Add("You fall down into the dry moat of the castle and quickly bleed out from your wound")
            lstDisplay.Items.Add("GAME OVER!")
        ElseIf input2 = True Then
            lstDisplay.Items.Add("You thrust the iron longsword from the armory forward, plunging it through the")
            lstDisplay.Items.Add("orc's chest, impaling it's heart. The lifeless corpse of the once great orc")
            lstDisplay.Items.Add("collapses on top of you. You quickly slid out from underneath, abondoning the sword still stuck within it's chest")
            lstDisplay.Items.Add("You grab the orc's axe and proceed into the castle")
            lstDisplay.Items.Add("")
            lstDisplay.Items.Add("Proceeding into the castle, you venture through the rooms and doorways, searching for what you came seeking")
            lstDisplay.Items.Add("You quickly realise that the main hallways are full of orcs. pillaging and ransacking the castle")
            lstDisplay.Items.Add("There are too many orcs to challenge alone")
            lstDisplay.Items.Add("")
            lstDisplay.Items.Add("There is a dark staircase leading downstairs. It looks dusty so it seems no orcs have ventured down there")
            lstDisplay.Items.Add("However, the roof above the orcs looks weak. Throwing the axe at it may break it")
            Do Until userinput3 = "Throw axe" Or "Go down the stairs" Or "throw axe" Or "go down the stairs" Or "throw" Or "stairs" Or "Stairs"
                userinput3 = InputBox("Throw axe or Go down the stairs")
            Loop
            If userinput3 = "Throw axe" Or "throw axe" Or "throw" Then
                lstDisplay.Items.Add("")
                lstDisplay.Items.Add("You throw the axe with all your might at the roof, but it merely bounced off and fell with a loud clash.")
                lstDisplay.Items.Add("The orcs turned to face you, large grins developing on their faces.")
                lstDisplay.Items.Add("Five of them rush you at once and make quick work of you")
                lstDisplay.Items.Add("Within one hour,  they had you spitroasted over a fire as dinner")
                lstDisplay.Items.Add("GAME OVER!")
            ElseIf userinput3 = "Go down the stairs" Or "go down the stairs" Or "stairs" Or "Stairs" Then
                lstDisplay.Items.Add("")
                lstDisplay.Items.Add("You proceed down the dark staircase. It leads you down to a room full of fancy weapons on display")
                lstDisplay.Items.Add("The room was full of jeweled katanas, finely crafted swords and even a golden dragonslaying spear")
                lstDisplay.Items.Add("In a large glass cabinet, a long black and dark green katana lay on display. A metal plate next to it titled it as Orc Slayer")
                lstDisplay.Items.Add("You had heard of this famed blade in a book a long time ago. Legend has it that would burn an entire orc to ashes as soon as it touched them")
                lstDisplay.Items.Add("You began to think that this sword would come in use")
                Do Until userinput4 = "Take sword" Or "Take" Or "Take orc slayer" Or "take the orc slayer" Or "Take the orc slayer" Or "take" Or "take sword" Or "keep axe" Or "Keep axe" Or "keep the axe" Or "Keep the axe"
                    userinput4 = InputBox("Take the Orc Slayer, or keep the axe?")
                Loop
                If userinput4 = "Take sword" Or "Take" Or "Take orc slayer" Or "take the orc slayer" Or "Take the orc slayer" Or "take" Or "take sword" Then
                    lstDisplay.Items.Add("")
                    lstDisplay.Items.Add("You put your axe down and open the display case. You take the sword. You feel its power already")
                    input3 = True
                ElseIf userinput4 = "keep axe" Or "Keep axe" Or "keep the axe" Or "Keep the axe" Then
                    lstDisplay.Items.Add("")
                    lstDisplay.Items.Add("You decide to keep your axe and proceed onward")
                End If
                lstDisplay.Items.Add("You keep walking through the dark tunnels beneath the castle, with no company  but rats, spiders and whatever that thing is you keep seeing in the dark out the corner of your eye")
                lstDisplay.Items.Add("Eventually, you find light once again. You walk out and look around. You were in the castle kitchens, located beneath the throne room.")
                lstDisplay.Items.Add("An orc in a dirty chef hat seems to be mixing a stew")
                lstDisplay.Items.Add("Probably best not to know whats in it though")
                lstDisplay.Items.Add("You decide it best to take him out, before he becomes a threat")
                If input3 = True Then
                    lstDisplay.Items.Add("You raise the Orc Slayer and ready it to take his head")
                    lstDisplay.Items.Add("However, you realise as you go to swing, the blade requires a lot of skill to wield")
                    lstDisplay.Items.Add("You end up swinging the blade down clumsily and miss the orc greatly. The blade slashes air and gets stuck in the woodwork")
                    lstDisplay.Items.Add("The orc jumps around to face you at the clumsy slash. He laughs and grabs his butcher's knife")
                    lstDisplay.Items.Add("The orc grabs you and licks his lips. He bets human meat would taste great in his stew")
                    lstDisplay.Items.Add("GAME OVER!")
                ElseIf input3 = False Then
                    lstDisplay.Items.Add("You raise the axe and slam it hard into his neck. You kick him forward to push the body off your axe")
                    lstDisplay.Items.Add("The orc's head went face first into the stew, his skin becoming another ingredient to the wretchid meal")
                    lstDisplay.Items.Add("")
                    lstDisplay.Items.Add("You walked out the kitchen and down the hallway. Then you reached it. The throne room.")
                    lstDisplay.Items.Add("You climbed the steps and gasped at the sight before you. The orc warchief, wearing the old king's crown on his head, and the old king's executioner's axe")
                    lstDisplay.Items.Add("You walked towards him, orc blood dripping from your axe. The chief laughed and readied himself for battle")
                    lstDisplay.Items.Add("")
                    lstDisplay.Items.Add("THE CHIEF SWUNG THE AXE TOWARDS YOU")

                    Do Until dodge1 = "Dodge right" Or "Right" Or "right" Or "dodge right" Or "Dodge left" Or "Left" Or "left" Or "dodge left"
                        dodge1 = InputBox("Dodge left or right!")
                    Loop

                    If dodge1 = "Dodge right" Or "Right" Or "right" Or "dodge right" Then
                        lstDisplay.Items.Add("Success! You dodge under the orc chief's swing!")
                        lstDisplay.Items.Add("You manage to swing your axe at the chief's leg while he recovers from his failed swing")

                    ElseIf dodge1 = "Dodge left" Or "Left" Or "left" Or "dodge left" Then
                        lstDisplay.Items.Add("The orc's swing catches you in the neck, sending your head flying across the throne room and down the steps")
                        lstDisplay.Items.Add("GAME OVER!")

                    End If

                    lstDisplay.Items.Add("THE CHIEF RECOVERS AND SWINGS THE AXE TOWARDS YOU AGAIN")

                    Do Until dodge2 = "Dodge right" Or "Right" Or "right" Or "dodge right" Or "Dodge left" Or "Left" Or "left" Or "dodge left"
                        dodge2 = InputBox("Dodge left or right!")
                    Loop

                    If dodge2 = "Dodge left" Or "Left" Or "left" Or "dodge left" Then
                        lstDisplay.Items.Add("Success! You dodge under the orc chief's swing!")
                        lstDisplay.Items.Add("You manage to swing your axe at the chief's leg while he recovers from his failed swing")
                        lstDisplay.Items.Add("The blows you dealt to the chief's legs cause him to fall to his knees and drop the executioner's axe")
                        lstDisplay.Items.Add("You quickly grab it and stand at the chief's side. You raise the axe up high and bring it down upon his head, severing it from his body")
                        lstDisplay.Items.Add("The headless body collapsed. The head fell to the floor, the crown on its head falling off and rolling to your feet")
                        lstDisplay.Items.Add("You drop the axe and pick up the crown. You carry it with you over to the throne. You sit down and perch the crown upon your head.")
                        lstDisplay.Items.Add("As you put it on, a tears through the city, cleansing it of dust and orcs and brings flesh back to the skeletons, the lives they one had returning as they reshaped")
                        lstDisplay.Items.Add("The king has returned to his throne and restored order.")
                        lstDisplay.Items.Add("However... years will pass and all will repeat itself. A wanderer finding the ancient kingdom of dust and standing at its gate")
                        lstDisplay.Items.Add("A wanderer much like you were until you remembered who you truly were")
                        lstDisplay.Items.Add("")
                        lstDisplay.Items.Add("But this cycle of wanderers and the city of dust will continue")
                        lstDisplay.Items.Add("Until the problem is solved...")
                        lstDisplay.Items.Add("The mystery of what happened to the kingdom of dust remains buried within the dust and until solved, the kingdom will forever be turned to dust and the cycle repeated")
                        lstDisplay.Items.Add("So serve the kingdom well... Your time is limited.")
                        lstDisplay.Items.Add("GAME OVER")
                        lstDisplay.Items.Add("Created By Stuart Paterson")

                    ElseIf dodge2 = "Dodge right" Or "right" Or "Right" Or "dodge right" Then
                        lstDisplay.Items.Add("The orc's swing catches you in the neck, sending your head flying across the throne room and down the steps")
                        lstDisplay.Items.Add("GAME OVER!")

                    End If
                End If

            End If
        End If



    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstDisplay.Items.Clear()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
